---
title: Demos
---

## Demos

- [Different grid types](grid-types)
- [Mobile-first "magic" grids](magic)

### Elsewhere

- [Off-Canvas layout with Susy][off-canvas]
- [Nettuts: Responsive Grids With Susy][nettuts]

[nettuts]: http://net.tutsplus.com/tutorials/html-css-techniques/responsive-grids-with-susy/
[off-canvas]: http://oddbird.net/2012/11/27/susy-off-canvas/

Have a tutorial you'd like to see?
[Contact us][twitter],
or [write it yourself][github].

[twitter]: http://twitter.com/compasssusy
[github]: https://github.com/ericam/susy/tree/master/docs/source/demos
